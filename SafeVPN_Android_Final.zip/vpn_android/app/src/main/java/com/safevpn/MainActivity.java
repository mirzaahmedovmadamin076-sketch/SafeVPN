package com.safevpn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    private static final int VPN_REQUEST_CODE = 1001;

    private boolean isConnected = false;
    private Button btnConnect;
    private TextView tvStatus, tvIp, tvPing, tvProtocol;
    private LinearLayout serverList;
    private CardView cardStats;
    private SharedPreferences prefs;
    private Handler handler = new Handler();

    // Serverlar
    private String[][] servers = {
        {"🇩🇪 Germaniya", "104.28.11.52", "18 ms"},
        {"🇳🇱 Niderlandiya", "185.220.101.7", "24 ms"},
        {"🇸🇬 Singapur", "103.86.99.12", "87 ms"},
        {"🇺🇸 AQSH", "198.211.107.25", "112 ms"},
    };
    private int selectedServer = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("vpn_prefs", MODE_PRIVATE);
        selectedServer = prefs.getInt("selected_server", 0);
        isConnected = false;

        initViews();
        renderServers();
        updateUI();
    }

    private void initViews() {
        btnConnect   = findViewById(R.id.btnConnect);
        tvStatus     = findViewById(R.id.tvStatus);
        tvIp         = findViewById(R.id.tvIp);
        tvPing       = findViewById(R.id.tvPing);
        tvProtocol   = findViewById(R.id.tvProtocol);
        serverList   = findViewById(R.id.serverList);
        cardStats    = findViewById(R.id.cardStats);

        btnConnect.setOnClickListener(v -> onConnectClick());

        // Split Tunneling tugmasi
        findViewById(R.id.btnSplitTunnel).setOnClickListener(v ->
            startActivity(new Intent(this, SplitTunnelActivity.class))
        );
    }

    private void onConnectClick() {
        if (!isConnected) {
            // VPN ruxsatini so'rash
            Intent intent = VpnService.prepare(this);
            if (intent != null) {
                startActivityForResult(intent, VPN_REQUEST_CODE);
            } else {
                startVPN();
            }
        } else {
            stopVPN();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            startVPN();
        }
    }

    private void startVPN() {
        // VPN Service ishga tushirish
        Intent intent = new Intent(this, VpnService.class);
        intent.putExtra("server_ip", servers[selectedServer][1]);
        intent.putExtra("server_name", servers[selectedServer][0]);
        startService(intent);

        // UI yangilash - ulanish animatsiyasi
        isConnected = true;
        btnConnect.setText("Ulanmoqda...");
        btnConnect.setEnabled(false);
        btnConnect.setBackgroundColor(0xFFEF9F27);

        handler.postDelayed(() -> {
            btnConnect.setText("VPN UZISH");
            btnConnect.setEnabled(true);
            btnConnect.setBackgroundColor(0xFF1D9E75);
            updateUI();
        }, 1500);
    }

    private void stopVPN() {
        Intent intent = new Intent(this, VpnService.class);
        stopService(intent);
        isConnected = false;
        updateUI();
    }

    private void updateUI() {
        if (isConnected) {
            tvStatus.setText("● Himoyalangan");
            tvStatus.setTextColor(0xFF1D9E75);
            tvIp.setText(servers[selectedServer][1]);
            tvPing.setText(servers[selectedServer][2]);
            tvProtocol.setText("WireGuard");
            btnConnect.setText("VPN UZISH");
            btnConnect.setBackgroundColor(0xFF1D9E75);
            cardStats.setCardBackgroundColor(0xFF0A2A1E);
        } else {
            tvStatus.setText("● Uzilgan");
            tvStatus.setTextColor(0xFFEF9F27);
            tvIp.setText("—");
            tvPing.setText("—");
            tvProtocol.setText("WireGuard");
            btnConnect.setText("VPN ULASH");
            btnConnect.setBackgroundColor(0xFF1A5FAA);
            cardStats.setCardBackgroundColor(0xFF162035);
        }
    }

    private void renderServers() {
        serverList.removeAllViews();
        for (int i = 0; i < servers.length; i++) {
            final int idx = i;
            View row = getLayoutInflater().inflate(R.layout.item_server, serverList, false);

            TextView name = row.findViewById(R.id.tvServerName);
            TextView ping = row.findViewById(R.id.tvServerPing);
            View indicator = row.findViewById(R.id.pingIndicator);

            name.setText(servers[i][0]);
            ping.setText(servers[i][2]);

            // Ping rang
            int pingMs = Integer.parseInt(servers[i][2].replace(" ms", ""));
            indicator.setBackgroundColor(pingMs < 50 ? 0xFF1D9E75 : 0xFFEF9F27);

            // Tanlangan server
            if (i == selectedServer) {
                row.setBackgroundColor(0xFFE6F1FB);
            }

            row.setOnClickListener(v -> {
                selectedServer = idx;
                prefs.edit().putInt("selected_server", idx).apply();
                renderServers();
                if (isConnected) updateUI();
            });

            serverList.addView(row);
        }
    }
}
