# SafeVPN — Android App

## Loyiha tuzilmasi
```
app/src/main/
├── AndroidManifest.xml
├── java/com/safevpn/
│   ├── MainActivity.java       ← Asosiy ekran (VPN ulash, server tanlash)
│   ├── VpnService.java         ← Haqiqiy Android VPN xizmati
│   └── SplitTunnelActivity.java ← Split Tunneling sozlamalari
└── res/layout/
    ├── activity_main.xml
    ├── activity_split_tunnel.xml
    ├── item_server.xml
    └── item_split_app.xml
```

## Android Studio da ochish

1. Android Studio ni oching
2. "Open an existing project" → bu papkani tanlang
3. Gradle sync tugashini kuting
4. Run → yoki `./gradlew assembleDebug`

## APK yaratish

```bash
# Debug APK
./gradlew assembleDebug

# APK joylashuvi:
app/build/outputs/apk/debug/app-debug.apk
```

## Funksiyalar

| Funksiya | Tavsif |
|----------|--------|
| VPN Ulash/Uzish | Bir tugma bilan |
| Server tanlash | 4 ta server (DE, NL, SG, US) |
| Split Tunneling | Har bir ilova uchun alohida yo'l |
| Bildirishnoma | VPN faol bo'lganda status bar da ko'rinadi |
| Sozlamalar saqlanadi | Ilova yopilsa ham saqlanadi |

## Eslatmalar

- Android 5.0 (API 21) va undan yuqori
- VPN ruxsati so'raladi (Android talabi)
- Haqiqiy WireGuard/OpenVPN uchun: wireguard-android kutubxonasini qo'shing
